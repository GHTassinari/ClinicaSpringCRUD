package br.edu.ifsuldeminas.machado.CrudManagerSpringClinicaVeterinaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudManagerSpringClinicaVeterinariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudManagerSpringClinicaVeterinariaApplication.class, args);
	}

}

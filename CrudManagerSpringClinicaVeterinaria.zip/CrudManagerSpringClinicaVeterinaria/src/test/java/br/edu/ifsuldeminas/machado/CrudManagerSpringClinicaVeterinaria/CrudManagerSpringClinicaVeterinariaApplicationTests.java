package br.edu.ifsuldeminas.machado.CrudManagerSpringClinicaVeterinaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudManagerSpringClinicaVeterinariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
